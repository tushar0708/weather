const express = require("express");
const bodyParser = require("body-parser");
const path = require("path");
const app = express();
const request = require('request');

const viewsDirPath = path.join(__dirname, "templates", "views");
app.use(bodyParser.urlencoded({ extended: false }));
app.set("view engine", "ejs");
app.set("views", viewsDirPath);
app.use(express.static(path.join(__dirname, "public")));

app.get("/", (req, res) => {
  res.render("index");
});




app.post("/weather", (req, res) => {
   console.log(req.body.city);
  const city= req.body.city;
  const apiKey= req.body.apikey;

  if(city != '' && apiKey !=''){
   const url =`http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

   request({url,json:true}, function (error, response, body) {
    console.error('error:', error); // Print the error if one occurred

    console.log('body:', body); // Print the HTML for the Google homepage.

  try {
    res.render("success", {
          dataWeather: body,
        });
  } catch (error) {
      throw error
  }

  })
}
else{
  res.render("failure", {
   
  });
}

  
});


app.listen(3000, () => {
  console.log("server started on port 3000");
});
